GMH UNCERTAINTY TRANSLATOR: DIY KIT
=====================================

WHAT THIS IS
------------
A free AI helper that turns your raw cattle inventory data (Excel/CSV)
into the input template expected by the Cattle Uncertainty App. This
kit lets you set it up on your own claude.ai account in about two
minutes: no payment, no installation.

DO YOU NEED THIS KIT?
---------------------
Probably not. The app has the same translator built in, on its
Resources tab, and it is easier to use: no setup, and it checks its
own output before you download it. Ask for access there first.

Use this kit if approval is still pending, if your ministry does not
allow uploading data to an external AI service run by someone else,
or if the app tells you its monthly cap has been reached.

SETTING IT UP (4 STEPS)
-----------------------
1. Sign up for a free account at https://claude.ai (Google / email / Apple).

2. In the left sidebar, click Projects, then Create project.
   Name it GMH Uncertainty Translator, or anything you like.

3. Open the project and find the Instructions field (top right).
   Open system_instructions.md from this kit in any text editor,
   select all, copy, and paste the contents into that field. Save.

4. Below the Instructions field is a Files panel. Drag these four
   files into it:
      - param_catalogue.md
      - template_schema.md
      - mapping_examples.md
      - worked_example.md

USING IT
--------
Start a new chat in your Project, upload your data file, and say what
it contains. The translator will ask you a few questions, then produce
the filled template. Upload that to the app's Data Input tab.

You do not need to prepare anything first. If you would rather decide
a few things in advance, before_you_start.md lists the four questions
no data file can answer.

Do one inventory per chat. A template covers one country and one year,
so start a fresh chat for the next one.

AFTER YOU GET THE TEMPLATE
--------------------------
This route has no quality preview, so check the output yourself:
compare population, body weight and milk yield against your source
file, and read the app's QA/QC tab after uploading.


