# Template schema

The app expects an `.xlsx` workbook with the sheets and columns below.
Sheet names and column headers are **case-sensitive and must match exactly**.

## Workbook overview

| sheet | required? | purpose |
|-------|-----------|---------|
| `_Lists` | optional (hidden) | dropdown vocabularies — created automatically when the user downloads the blank template; safe to omit when you (Claude) build a workbook from scratch |
| `README` | optional | human-readable quick-start — safe to omit |
| `Inventory_Metadata` | **required** | country, region, year, IPCC version, species |
| `Parameters` | **required** | the 25 parameters per cattle sub-category |
| `Manure_Management` | **required** | per-MMS allocation; per-group fractions must sum to 100% |
| `Parameter_TimeSeries` | optional | 5+ years of annual values for auto-correlation |
| `Vocab` | optional | reference catalogue — safe to omit |

## Sheet: `Inventory_Metadata`

Transposed (label/value) layout, one field per row starting at row 2. Column B is the label, column C is the value, column D a hint. The parser locates the value column by its header `Value`, so a workbook built from scratch may also use label in A and value in B.

| label (column B) | field | value | notes |
|-------|-------|-------|-------|
| Country | `country` | (free text) | e.g. `Zimbabwe`. Used in the report header. |
| Continental region | `region` | one of: africa / asia / europe / americas / oceania / global | Continental region — drives the BW plausibility benchmark (IPCC Vol.4 Ch.10 Annex 10A.1/10A.2). Always set it from the country; never leave it to default. |
| Inventory year | `inventory_year` | (integer) | e.g. `2022` |
| Livestock species | `species` | one of: cattle_dairy / cattle_non_dairy / cattle_mixed / buffalo | controlled vocabulary |
| IPCC Guidelines version | `ipcc_version` | one of: 2006 / 2019_refinement | drives MMS list filtering and the edition-specific Ym |
| Prepared by | `prepared_by` | (free text) | name / institution |
| Notes | `notes` | (free text) | optional; the translator appends its provenance stamp here |

## Sheet: `Parameters`

Banner in row 1, legend in row 2, header row in row 3. Data starts at row 4. One row per (cattle_type × aggregation_level × sub_category × parameter).

| col | header | required? | notes |
|-----|--------|-----------|-------|
| A | cattle_type | yes | e.g. `dairy`, `non_dairy` |
| B | aggregation_level | yes | free text label for the inventory grouping (production system, region, AEZ) |
| C | sub_category | yes | one of the ANIMAL_SUBCATEGORIES below (or free-text if the inventory uses custom groups) |
| D | parameter | yes | the parameter code from param_catalogue.md |
| E | definition | no | optional human label (mirrors param_catalogue) |
| F | unit | no | optional unit (mirrors param_catalogue) |
| G | value | yes | the central value — **the number the user is providing** |
| H | uncertainty_pct | one of (uncertainty_pct) or (lower/upper) | symmetric ±% half-width of 95% CI |
| I | lower_bound | no | catalogue reference bound, display only; the model writes bounds to `lower` / `upper` |
| J | upper_bound | no | catalogue reference bound, display only |
| K | distribution | yes | one of the distribution codes in param_catalogue.md |
| L | lower | one of (uncertainty_pct) or (lower/upper) | explicit lower bound; this is the cell the simulator reads |
| M | upper | one of (uncertainty_pct) or (lower/upper) | explicit upper bound; this is the cell the simulator reads |
| N | param_type | yes | `activity_data` (only for `N`) or `coefficient` |
| O | ipcc_ref | no | citation, e.g. `Table 10.4` |
| P | data_source | yes | one of: `user_file`, `user_chat`, `ipcc_default`, `biological_zero`, `placeholder` |

### Sub-category codes (ANIMAL_SUBCATEGORIES)

- `dairy_cows` — Dairy Cows (mature lactating females)
- `other_cows` — Other Cows (mature non-dairy females, inc. dry)
- `bulls` — Bulls (mature intact males, breeding)
- `oxen` — Oxen (mature castrated males)
- `heifers` — Heifers (young females 1-3yr, not yet calved)
- `growing_males` — Growing Males (young males 1-3yr, steers/bulls)
- `calves_female` — Calves - Female (<1yr)
- `calves_male` — Calves - Male (<1yr)
- `feedlot_cattle` — Feedlot Cattle (concentrated feeding)

## Sheet: `Manure_Management`

Banner in row 1, header row in row 2, hints in row 3. Data starts at row 4. One row per (cattle_type × aggregation_level × sub_category × mms_type). Per-group rows must sum to fraction_pct = 100.

Units on this sheet: `fraction_pct`, `MCF_pct`, `Frac_GasMS_pct` and `Frac_LeachMS_pct` are PERCENTAGES (5 means 5 %). `EF3` is a FRACTION (0.01). Never write an MCF as 0.05 to mean 5 %.

| col | header | required? | notes |
|-----|--------|-----------|-------|
| A | cattle_type | yes | matches Parameters sheet |
| B | aggregation_level | yes | matches Parameters sheet |
| C | sub_category | yes | matches Parameters sheet (auto-matched on upload if a near-spelling exists in Parameters, e.g. `DINT_heif` ↔ `DINT_heifer`) |
| D | mms_type | yes | controlled vocabulary (below) |
| E | fraction_pct | yes | % of manure to this MMS; rows per group must sum to 100 |
| F | lower_fraction | no | min % for fraction_pct uncertainty (optional, enables per-MMS allocation sampling) |
| G | upper_fraction | no | max % for fraction_pct uncertainty |
| H | distribution_fraction | no | distribution code for fraction_pct (default `pert`). Rows are renormalised per iteration so the simplex (sum = 100) is preserved. |
| I | MCF_pct | yes | methane conversion factor in PERCENT (e.g. 5 for 5 %) — see climate-zone table |
| J | lower_mcf | no | for asymmetric ranges, percent |
| K | upper_mcf | no | for asymmetric ranges, percent |
| L | distribution_mcf | no | distribution code for MCF |
| M | EF3 | yes | direct N₂O EF (kg N₂O-N/kg N) for this MMS, a FRACTION (e.g. 0.01) |
| N | lower_ef3 | no |  |
| O | upper_ef3 | no |  |
| P | distribution_ef3 | no |  |
| Q | Frac_GasMS_pct | yes | per-MMS volatilisation fraction in PERCENT (e.g. 45) — defaults from IPCC 2019 Table 10.22 |
| R | lower_frac_gas | no | percent |
| S | upper_frac_gas | no | percent |
| T | distribution_frac_gas | no |  |
| U | Frac_LeachMS_pct | yes | per-MMS leaching fraction in PERCENT (e.g. 2) — defaults from IPCC 2019 Table 10.22 |
| V | lower_frac_leach | no | percent |
| W | upper_frac_leach | no | percent |
| X | distribution_frac_leach | no |  |

### MMS types — by IPCC version

| id | label | 2006? | 2019R? | MCF trop.moist | MCF trop.dry | MCF temperate | MCF boreal | EF3 |
|----|-------|-------|--------|----------------|--------------|---------------|------------|-----|
| `pasture` | Pasture/Paddock/Range | ✓ | ✓ | 2 | 2 | 1.5 | 1 | 0.02 |
| `daily_spread` | Daily Spread | ✓ | ✓ | 1 | 1 | 0.5 | 0.1 | 0 |
| `solid_storage` | Solid Storage | ✓ | ✓ | 5 | 5 | 4 | 2 | 0.01 |
| `solid_storage_covered` | Solid Storage – Covered/Compacted (2019) |  | ✓ | 5 | 5 | 4 | 2 | 0.01 |
| `dry_lot` | Dry Lot | ✓ | ✓ | 2 | 2 | 1.5 | 1 | 0.02 |
| `deep_bedding` | Deep Bedding (>1 month) | ✓ | ✓ | 80 | 80 | 39 | 17 | 0.01 |
| `liquid_slurry` | Liquid/Slurry (with natural crust cover) | ✓ | ✓ | 50 | 50 | 24 | 10 | 0.005 |
| `composting` | Composting - Static Pile (forced aeration) | ✓ | ✓ | 0.5 | 0.5 | 0.5 | 0.5 | 0.01 |
| `lagoon` | Anaerobic Lagoon | ✓ | ✓ | 80 | 80 | 77 | 66 | 0 |
| `anaerobic_digester` | Anaerobic Digester / Biogas (low leakage, open storage) |  | ✓ | 4.59 | 4.59 | 4.38 | 3.55 | 0.0006 |
| `aerobic_treatment` | Aerobic Treatment (2019) |  | ✓ | 0 | 0 | 0 | 0 | 0.005 |
| `burned_for_fuel` | Burned for Fuel (2019) |  | ✓ | 10 | 10 | 10 | 10 | 0 |

### Per-MMS volatilisation & leaching defaults (IPCC 2019 Refinement)

Use these when filling Frac_GasMS_pct and Frac_LeachMS_pct. The table gives FRACTIONS; multiply by 100 for the sheet.

| mms_type | Frac_Gas (mean / low / high) | Frac_Leach (mean / low / high) |
|----------|------------------------------|--------------------------------|
| `pasture` | 0 / 0 / 0 | 0 / 0 / 0 |
| `daily_spread` | 0.07 / 0.05 / 0.6 | 0 / 0 / 0 |
| `solid_storage` | 0.45 / 0.1 / 0.65 | 0.02 / 0.01 / 0.03 |
| `solid_storage_covered` | 0.22 / 0.03 / 0.26 | 0 / 0 / 0 |
| `dry_lot` | 0.3 / 0.2 / 0.5 | 0.035 / 0 / 0.07 |
| `deep_bedding` | 0.25 / 0.1 / 0.3 | 0.035 / 0 / 0.07 |
| `liquid_slurry` | 0.3 / 0.09 / 0.36 | 0 / 0 / 0 |
| `anaerobic_digester` | 0.48 / 0.15 / 0.6 | 0 / 0 / 0 |
| `composting` | 0.65 / 0.14 / 0.7 | 0.06 / 0.03 / 0.09 |
| `aerobic_treatment` | 0.85 / 0.27 / 1 | 0 / 0 / 0 |
| `lagoon` | 0.35 / 0.2 / 0.8 | 0 / 0 / 0 |
| `burned_for_fuel` | 0 / 0 / 0 | 0 / 0 / 0 |

## Sheet: `Parameter_TimeSeries` (optional)

Banner in row 1, header row in row 2, description in row 3, units in row 4. Data starts at row 5. Annual values, used to compute Spearman-rank correlations between activity-data parameters. Minimum 5 years (or 4 if first-difference detrending is used).

| col | header | notes |
|-----|--------|-------|
| A | cattle_type | optional — blank = applies to all groups |
| B | aggregation_level | optional |
| C | sub_category | optional |
| D | year | required (integer) |
| E–N | N, BW, MW, WG, Milk, Fat, pct_pregnant, DE, CP, MilkPR | the 10 parameters the app correlates; leave columns blank for parameters not measured |

## Validation rules the app applies

These are the checks Claude should run before declaring the workbook ready:

- **bounds**: `lower ≤ value ≤ upper` for every Parameters row (exception: when `distribution = constant` and all three = 0, e.g. WG for adults, hours for non-working cattle)
- **N ≥ 0** (cattle population can't be negative)
- **DE ∈ [0, 100]**, **Ym > 0**, Parameters-sheet fractions (`pct_pregnant`, `ASH`, `UE`, `Frac_GASM_PRP`, `Frac_LEACH_PRP`) ∈ [0, 1]; Manure_Management percentages ∈ [0, 100]
- **distribution** ∈ DISTRIBUTION_TYPES
- **param_type** ∈ {`activity_data`, `coefficient`}
- **Manure_Management**: per (cattle_type, aggregation_level, sub_category), `fraction_pct` central values sum to 100 ± 1 (bounds may widen; the app renormalises each Monte Carlo iteration to preserve the simplex when `lower_fraction` / `upper_fraction` are supplied)
- **Manure_Management**: `lower_fraction ≤ fraction_pct ≤ upper_fraction` for every row that supplies the uncertainty columns; blank = deterministic
- **Manure_Management**: `sub_category` should match the Parameters sheet exactly. Near-spellings (e.g. `DINT_heif` vs `DINT_heifer`) are auto-matched on upload and shown as a `warn` row in the QAQC tab; multi-candidate ambiguity blocks the run
- **Manure_Management**: mms_type must be a valid id for the selected IPCC version
- **Inventory_Metadata.species** ∈ SPECIES_OPTIONS; **ipcc_version** ∈ IPCC_VERSIONS

## Distribution choice guide

When the user gives you a value but no distribution, pick from this priority list:

1. If the parameter has an asymmetric IPCC range (`EF3_PRP`, `EF4`, `EF5`, `Frac_GASM_PRP`, `Frac_LEACH_PRP`) → use **`lognormal`** or **`pert`** with the absolute bounds from the asymmetric table in param_catalogue.md.
2. If the parameter is a fraction bounded in [0, 1] (pct_pregnant, ASH, UE, manure fractions) → **`beta`** or **`tnorm_0_1`**.
3. If the central value comes from a measured mean ± SD or ±CV → **`normal`**.
4. If only min / mode / max are known (expert judgement) → **`pert`** (preferred) or **`triangular`**.
5. If the parameter is structurally constant (WG = 0 for adults, hours = 0 for non-working cattle) → **`constant`**, lower = value = upper.

